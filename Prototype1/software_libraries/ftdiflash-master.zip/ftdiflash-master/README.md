# ftdiflash
simple SPI flash programmer for use with FTDI USB devices

See the guide here: https://learn.adafruit.com/programming-spi-flash-prom-with-an-ft232h-breakout/overview

This is a modified version of the iceprog tool from the excellent Icestorm FPGA toolchain by Clifford Wolf
https://github.com/cliffordwolf/icestorm
